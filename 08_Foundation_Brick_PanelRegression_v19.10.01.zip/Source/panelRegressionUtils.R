packages <- NULL
git_url <- NULL
project_issue_url <- NULL
session_url <- NULL
projectID <- NULL
# Global variables
loadGlobals <- function(){
  projectID <<- 96
  git_url <<- "http://mugitlab.mu-sigma.com/api/v3"
  project_issue_url <<- "http://mugitlab.mu-sigma.com/api/v3/projects/96/issues"
  session_url <<- "http://mugitlab.mu-sigma.com/api/v3/session"
  alfresco_url <<- 'https://eoc.mu-sigma.com/alfresco/api/-default-/public/alfresco/versions/1/nodes/'
  alfresco_cred <<- list(u = "scrumbot", p = "musigma@123")
  packages <<- c("colourpicker","DT","rjson", "ggplot2", "shiny", "shinyjs", "shinyBS", "colourpicker", "xtable", "knitr", "rmarkdown", 
                "qgraph", "pander", "dplyr", "png", "grid", "gridExtra", "htmlTable", "reshape2", "dplyr", "reshape", 
                "dummies", "REEMtree", "rpart.plot", "caTools", "nlme", "lme4", "lattice", "pROC", "classifierplots", "httr","DT","prettydoc")
  dbPackages <<- c("rJava", "RPostgreSQL", "RMySQL", "RSQLite", "DBI","RJDBC", "odbc")
  generalMsgWarningHdr <<- "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:"
  packageList <<-   if(file.exists("Source/packageList.csv")){
    packageList <<- read.csv("Source/packageList.csv")
  } else if(file.exists("packageList.csv")){
    packageList <<- read.csv("packageList.csv")
  } else {
    packageList <<- NULL
  }
}

# Function to calculate MAPE
calculateMAPE <- function(actual, predicted) {
  actualZeroes <- which(actual == 0)
  if(length(actualZeroes) > 0) {
    actual <- actual[-actualZeroes]
    predicted <- predicted[-actualZeroes]
  }
  if(length(actual) != length(predicted)) {
    warning("Actual and Predicted are not in the same length. MAPE incorrect.")
  }
  100*mean(abs((actual-predicted)/actual))
}


# Get the corrected p-value for ANOVA output. 
## Note: This function is needed because when a variable is removed from the random effects, 
## the degrees of freedom will decrease by number of random coefficients chosen i.e., 1 for random coef & 1 for it's covariance with other coefs
## since these distrbutions are very different, we calculate the p-values for each of them individually, and then average them.
pvalCorrected <- function(chisq, df){
  
  pVals <- lapply(0:(df-1), function(i){ stats::pchisq(chisq, df-i, lower.tail = FALSE) })
  corrected <- sum(unlist(pVals))/df
  return(corrected)
}

# Function to build RE-EM tree 
getReemTree <- function(fixed.f, random.f, data) {
  
  set.seed(10)
  reemTree <- REEMtree::REEMtree(formula = formula(fixed.f), random = eval(parse(text = random.f)), 
                       data = data, MaxIterations = 2)
  return(reemTree)
}

# Run forward stepwise selection to select the best features as fixed effects
# Credits: http://www.rensenieuwenhuis.nl/r-sessions-32/
forwardStepwiseLMER <- function(baseModel, blocks, max.iter = 100, sig.level = 0.05, 
                                progIndicator = FALSE, progressObj = NA) {
  
  if(class(baseModel) != 'lmerMod') {
    stop('base model should be of class LMER')
  }
  
  log.step <- 0
  log.LL <- NA
  log.block <- NA
  log.p <- NA
  
  # Maximum number of iterations cannot exceed number of blocks
  if(max.iter > length(blocks)) max.iter <- length(blocks)
  
  for (i in 1:max.iter) {
    if(progIndicator) {
      progressObj$inc(1/max.iter)
    }

    # Iteratively updating the base model with addition of one block of variable(s)
    models <- lapply(blocks, function(x) {
      stats::update(baseModel, as.formula(paste(". ~ . + ", x)))
    })

    # Unlisting the list elements to apply logLik 
    LL <- unlist(lapply(models, logLik))

    # flag to stop iterating if a better model was not found in the current iteration
    modelUpdatedFlag <- FALSE
    
    # Iterating through the models, in the decreasing order of their significance
    for (j in order(LL, decreasing = TRUE)) {
      
      # Selection based on ANOVA-test
      # Replace the base model by new model if it is lower than the expected significance level
      pval <- stats::anova(baseModel, models[[j]])
      
      if(pval[2, 8] < sig.level) {
        baseModel <- models[[j]]
        
        # Recording the features
        log.step <- log.step + 1
        log.block[log.step] <- blocks[j]
        log.LL[log.step] <- LL[j]
        log.p[log.step] <- pval[2, 8]
        
        # Removing the variable from blocks as it has already been added to the model
        blocks <- blocks[-j]
        modelUpdatedFlag <- TRUE
        break
      }
    }
    
    if(!modelUpdatedFlag) break
  }
  
  # Combining all the logs
  log.df <- data.frame(log.step = 1:log.step, log.block, log.LL, log.p, stringsAsFactors = FALSE)
  return(log.df)
}


# Generating train-validation datasets
generateTrainTestData <- function(dataset, modelVars, sampleRatio, dividePerPanel) {
  
  if(sampleRatio <= 0 || sampleRatio >= 1) {
    stop('Please provide the ratio between 0 and 1')
  }
  
  if(dividePerPanel) {
    
    # Continue with sampling per L1 Panel only if the data is balanced
    # Stratified sampling with sequence
    if(modelVars$Timevar != "") {
      
      # Generate train and test by taking the 1st n rows per panel as train and the remaining as test.
      dfRows <- unlist(dataset %>% group_by_(modelVars$PanelL1) %>% summarise(n = n()) %>% select(n))
      trainingData <- 1:round(dfRows[1]*sampleRatio)
      for(i in 2:length(dfRows)) {
        trainRows <- round(dfRows[i]*sampleRatio)
        trainingData <- c(trainingData, (1:trainRows)+sum(dfRows[1:(i-1)]))
      }
      testData <- setdiff(1:nrow(dataset), trainingData)
      
    } else {
      # Stratified random sampling
      # Generate train and test by stratified random sampling
      trainIndex <- caTools::sample.split(dataset[,modelVars$PanelL1], sampleRatio)
      trainingData <- which(trainIndex)
      testData <- setdiff(1:nrow(dataset), which(trainIndex))
    }
    
  } else {
    # If the user has not selected 'Divide data per panel' option, sample entire groups of L1 panel, based on L2 panel
    if(modelVars$PanelL2 == "") {
      uniquePanels <- unique(dataset[,modelVars$PanelL1])
      samplePanelsIndex <- sort(sample(1:length(uniquePanels), round(length(uniquePanels)*sampleRatio), replace = FALSE))
      trainPanels <- uniquePanels[samplePanelsIndex]
      testPanels <- uniquePanels[-samplePanelsIndex]
    } else {
      uniquePanels <- unique(dataset[,c(modelVars$PanelL1,modelVars$PanelL2)])
      samplePanelsIndex <- caTools::sample.split(uniquePanels[,modelVars$PanelL2], sampleRatio)
      trainPanels <- uniquePanels[samplePanelsIndex,1]
      testPanels <- uniquePanels[-samplePanelsIndex,1]
    }

    trainingData <- which(dataset[,modelVars$PanelL1] %in% trainPanels)
    testData <- which(dataset[,modelVars$PanelL1] %in% testPanels)
  }
  
  # indices for training and test data are returned
  return(list(train = trainingData, test = testData))
}

#### Formula generation ####

# Returns a string for random effects to add up in the formula
getRandomLME <- function(panelList){
  
  if(is.null(panelList$panelName) || panelList$panelName == '') {
    return(NA)
  }
  
  # Generating the right pdMat class for the formula
  if(panelList$reCorr == 'Diagonal') {
    reCorrString <- 'nlme::pdDiag('
  } else if(panelList$reCorr == 'Compound Symmetry') {
    reCorrString <- 'nlme::pdCompSymm('
  } else if(panelList$reCorr == 'Identity') {
    reCorrString <- 'nlme::pdIdent('
  } else if(panelList$reCorr == 'Unstructured') {
    reCorrString <- '('
  } else {
    warning('Cannot recognize covariance structure specified. Using unstructured')
    reCorrString <- '('
  }
  
  # Individual Random effect string construction
  if(length(panelList$randomEffects) == 0){
    # No random effects
    partFormula <- paste0(panelList$panelName,"= (~ 1)")
  } else if(panelList$intercept) {
    partFormula <- paste0(panelList$panelName,"= ", reCorrString," ~ 1 + ", paste(paste(panelList$randomEffects), collapse = " + "), ")")
  } else {
    partFormula <- paste0(panelList$panelName,"= ", reCorrString, " ~ ", paste(paste(panelList$randomEffects), collapse = " + ")," + 0)")
  }
  
  return(partFormula)
}


# Returns an array of the fixed and random formulae
getFormulaLME <- function(Yvar, L1, L2, fixedEffects) {
  
  if(is.null(L1$panelName) || L1$panelName == '' || is.null(L2$panelName)) {
    return(NA)
  }
  
  if(length(fixedEffects) == 0) {
    fixedEffects <- '1'
  } else {
    fixedEffects <- fixedEffects[fixedEffects != '1']
  }
  
  # When only L1 exists
  if(L2$panelName == ''){
    # No hierarchical panels
    REformulaL1 <- getRandomLME(L1)
    f <- c(paste0(Yvar, " ~ ", paste(fixedEffects, collapse = " + ")),paste0("list(",REformulaL1,")"))
  }
  # When L2 exists
  else {
    # if L2 panel has only fixed effect
    if(is.null(L2$intercept)){
      REformulaL1 <- getRandomLME(L1)
      if(fixedEffects[1] == 1 && length(fixedEffects) == 1) {
        f <- c(paste0(Yvar, " ~ 1"),paste0("list(",REformulaL1,")"))
      } else {
        f <- c(paste0(Yvar, " ~ ", paste(paste0(fixedEffects, "*", L2$panelName), collapse = " + ")),paste0("list(",REformulaL1,")"))
      }
    }
    # if both L1 and L2 have random effect
    else {
      REformulaL1 <- getRandomLME(L1)
      REformulaL2 <- getRandomLME(L2)
      f <- c(paste0(Yvar, " ~ ", paste(paste0(fixedEffects), collapse = " + ")),paste0("list(",REformulaL2,", ",REformulaL1,")"))
    }
  }
  return(f)
}


# Function to generate random effects for LMER
getRandomLMER <- function(panelList) {
  
  if(is.null(panelList$panelName) || panelList$panelName == '') {
    return(NA)
  }
  
  if(length(panelList$randomEffects) == 0) {
    partFormula <- paste0("(1 | ", panelList$panelName, ")")
    
  } else {
    # generating random effects based on the correlation structure chosen
    if(panelList$reCorr == 'Diagonal') {
      if(panelList$intercept) {
        partFormula <- paste0("(1 | ", panelList$panelName, ") + ", paste(paste0("(0 + ", panelList$randomEffects, " | ", panelList$panelName, ")"), collapse = " + "))
      } else {
        partFormula <- paste(paste0("(0 + ", panelList$randomEffects, " | ", panelList$panelName, ")"), collapse = " + ")
      }
      
    } else {
      if(panelList$intercept) {
        partFormula <- paste0("(1 + ", paste(panelList$randomEffects, collapse = " + "), " | ", panelList$panelName, ")")
      } else {
        partFormula <- paste0("(0 + ", paste(panelList$randomEffects, collapse = " + "), " | ", panelList$panelName, ")")
      }
      
      if(panelList$reCorr != 'Unstructured') {
        warning('Cannot recognize covariance structure specified. Using unstructured')
      }
    }
  }
  return(partFormula)
}


# Function to generate formula for LMER
getFormulaLMER <- function(Yvar, L1, L2, fixedEffects) {
  
  
  if(is.null(L1$panelName) || L1$panelName == '' || is.null(L2$panelName)) {
    return(NA)
  }
  
  if(length(fixedEffects) == 0) {
    fixedEffects <- '1'
  } else {
    fixedEffects <- fixedEffects[fixedEffects != '1']
  }
  
  if(L2$panelName == ''){
    
    # When only L1 exists
    REformulaL1 <- getRandomLMER(L1)
    f <- paste0(Yvar, " ~ ", paste(fixedEffects, collapse = " + "), " + ", REformulaL1)
    
  } else {
    if(is.null(L2$intercept)) {
      # If L2 panel has only fixed effects
      REformulaL1 <- getRandomLMER(L1)
      if(fixedEffects[1] == 1 && length(fixedEffects) == 1) {
        f <- paste0(Yvar, " ~ 1 + ", REformulaL1)
      } else {
        f <- paste0(Yvar, " ~ ", paste(paste0(fixedEffects, "*", L2$panelName), collapse = " + "), " + ", REformulaL1)
      }
      
    } else {
      # If both L1 and L2 have random effects
      REformulaL1 <- getRandomLMER(L1)
      REformulaL2 <- getRandomLMER(L2)
      f <- paste0(Yvar, " ~ ", paste(fixedEffects, collapse = " + "), " + ", REformulaL2, " + ", REformulaL1)
    }
  }
  return(f)
}

#### Models ####

# Build a mixed model using LME for the given parameters. Returns a NULL when the model building fails
buildLmmModel <- function(trainData, formulaList, errCorrelation){
  
  # creating the model
  modelResult <- tryCatch({
    eval(parse(text=paste0("nlme::lme(fixed = ",formulaList[1],", random = ",formulaList[2],", data = trainData, correlation = ",errCorrelation,", na.action = na.omit)")))
  }, error = function(e) {
    print(paste("ERROR IN BUILDING LME MODEL:", e))
    return(e)
  })
  
  if(class(modelResult)[1] == "lme") {
    return(list(model = modelResult, success = TRUE, error = ""))
  } else {
    return(list(model = NULL, success = FALSE, error = modelResult))
  }
}


# Function to evaluate the base model and remove unnecessary random coefficients based on p-values from anova
evaluateLmmModels <- function(trainData, Yvar, L1, L2, fixedEffects, errCorrelation){
  
  # the default formula
  f <- getFormulaLME(Yvar, L1, L2, fixedEffects)
  baseModelList <- buildLmmModel(trainData, f, errCorrelation)
  
  # if the default model ran and optimsation check was true
  if(baseModelList$success){
    
    baseModel <- baseModelList$model
    
    if(L1$intercept == TRUE){
      # vector of all random effects
      randomWithIntercept <- c("(intercept)",L1$randomEffects)
    }else{
      randomWithIntercept <- L1$randomEffects
    }
    
    # copying L1
    tempL1 <- L1
    
    if(length(L1$randomEffects)>0) {
      
      modelList <- lapply(randomWithIntercept, FUN = function(r) {
        tempL1$randomEffects <- L1$randomEffects[L1$randomEffects != r]
        if(r == "(intercept)") {
          tempL1$intercept <- FALSE 
        } else {
          tempL1$intercept <- L1$intercept
        }
        
        f <- getFormulaLME(Yvar, tempL1, L2, fixedEffects)
        modelCheck <- buildLmmModel(trainData, f, errCorrelation)
        return(modelCheck$model)
      })
      
      # checking and removing NULL models
      names(modelList) <- randomWithIntercept
      modelList[sapply(modelList, is.null)] <- NULL
    } else {
      modelList <- list()
    }
    
    if(length(modelList)!=0){
      
      # compare with base model using ANOVA
      anovaResult <- lapply(modelList, FUN = function(testModel){
        anova(baseModel, testModel)
      })
      
      # creating the best fit model based on comparision and analysis
      randomEffectIndicators <- lapply(1:length(anovaResult), FUN = function(i){
        # forbid model optimization, when differences in degrees of freedom, between models is zero
        if(abs(anovaResult[[i]]$df[1]-anovaResult[[i]]$df[2])!=0){
          pValue <- pvalCorrected(anovaResult[[i]]$L.Ratio[2],abs(anovaResult[[i]]$df[1]-anovaResult[[i]]$df[2]))
          anovaResult[[i]][2,'p-value'] <<- pValue
          omitRE <- ifelse(pValue >= 0.05, names(anovaResult)[i], NA)
          return(omitRE)
        }else{
          return(NA)
        }
      })
      
      # the effects that we will omit
      randomEffectIndicators[sapply(randomEffectIndicators, is.na)] <- NULL
      randomEffectIndicators <- unlist(randomEffectIndicators)
      
      # new set of random effects
      goodRE <- setdiff(randomWithIntercept, randomEffectIndicators)
      
      if(length(goodRE) > 0) {
        # final model and formula 
        if("(intercept)" %in% goodRE) {
          tempL1$randomEffects <- setdiff(goodRE, "(intercept)")
          tempL1$intercept <- TRUE
        } else {
          tempL1$randomEffects <- goodRE
          tempL1$intercept <- FALSE
        }
        f <- getFormulaLME(Yvar, tempL1, L2, fixedEffects) 
        
        modelFinalList <- buildLmmModel(trainData, f, errCorrelation)
        modelFinal <- modelFinalList$model
        
        if(!modelFinalList$success){
          # returning base model since optimised model threw an error
          e <- "WARNING: The model with optimized radom effects included threw an error. Returning the base model with all random effects specified."
          return(list("model" = baseModel, "RE" = L1$randomEffects, error = e, anova = anovaResult))
          
        }else{
          # optimised model output
          return(list("model" = modelFinal, "RE" = setdiff(goodRE, "(intercept)"), error = '', anova = anovaResult))
        }
      } else {
        # returning base model since none of the random effects satisfy the p-value
        e <- "WARNING: None of the random effects came out to be significant. Returning the default model with all random effects specified."
        return(list("model" = baseModel, "RE" = L1$randomEffects, error = e, anova = anovaResult))
      }
    }else{
      # returning base model since all combinations threw error
      return(list("model" = baseModel, "RE" = L1$randomEffects, error = '', anova = NULL))
    }
  } else {
    return(c(baseModelList, "RE" = NULL, error = '', anova = NULL))
  }
}


# Predict function to handle for predicting panels that were not available for training
predictLMM <- function(model, newdata) {
  
  if(class(model)[1] == 'lme') {
    groups <- model$groups
    groupName <- colnames(groups)
    
    predicted <- stats::predict(model, newdata = newdata, level = c(0:length(groupName)))
    
    # Return the random effects if it was trained with it, else return fixed effect prediction
    newPredicted <- apply(predicted, 1, function(row) {
      rowCleaned <- row[!is.na(row)]
      bestPred <- tail(rowCleaned, 1)
      return(as.numeric(bestPred))
    })
    return(newPredicted)
  } else {
    warning('Cannot predict for a non-lme model')
    return(NA)
  }
}


# Build a generalized mixed model using LMER for the given parameters. Returns a NULL when the model building fails
buildGmmModel <- function(trainData, formulaList, gmmFamily){
  
  # creating the model
  modelResult <- tryCatch({
    lme4::glmer(formula = formulaList, data = trainData, family = gmmFamily)
  }, error = function(e) {
    print(paste("ERROR IN BUILDING LMER MODEL:", e))
    return(e)
  })
  
  if(class(modelResult)[1] == "glmerMod") {
    return(list(model = modelResult, success = TRUE, error = ""))
  } else {
    return(list(model = NULL, success = FALSE, error = modelResult))
  }
}


# User-defined predict function to handle for predicting panels that were not available for training
predictGMM <- function(model, newdata) {
  if(class(model)[1] == "glmerMod") {
    predicted <- stats::predict(model, newdata, allow.new.levels = TRUE, type = "response")
    return(predicted)
  } else {
    warning('Cannot predict for a non-glmer model')
    return(NA)
  }
}


#### Plots ####

## Feature selection plot
featureSelectionPlot <- function(data, varsToDisplay, title, primaryColor, secondaryColor) {
  
  varsToDisplay <- min(varsToDisplay, nrow(data))
  # reordering data to descending and filtering the top variables to display
  data[,'Features'] <- with(data, reorder(Features, Importance))
  data <- data[1:varsToDisplay,]
  
  ggplot2::ggplot(data, ggplot2::aes(x = Features, y = Importance)) + 
    ggplot2::geom_bar(color='grey90', fill=primaryColor, stat = "identity",position = "dodge") + 
    ggplot2::coord_flip() + ggplot2::ylab("Importance") + ggplot2::xlab("Features") + 
    ggplot2::labs(title = title) + ggplot2::theme(plot.title = ggplot2:: element_text(hjust = 0.5)) +
    ggplot2::theme(legend.position=c(0.8,0.8),
          legend.background = ggplot2:: element_rect(fill=scales::alpha('white', 0)),
          legend.direction = "vertical",
          plot.title = ggplot2:: element_blank(),
          axis.title=ggplot2:: element_text(size=14))
}

# get point of intersection for sensitivity-specificity graph
intersection <- function(x1, y1, x2, y2, x3, y3, x4, y4) { 
  
  arguments <- list(x1, y1, x2, y2, x3, y3, x4, y4)
  
  m1 = (y2-y1)/(x2-x1)
  m2 = (y4-y3)/(x4-x3)
  
  if(any(sapply(arguments, is.null))) {
    warning("One or more points in argument is NULL")
  } else if(any(sapply(arguments, is.na))) {
    warning("One or more points in argument is NA")
  } else if(!all(sapply(arguments, is.finite)) & all(sapply(arguments, is.numeric))) {
    warning("One or more points in argument is non finite")
  } else if(m1 == m2) {
    warning("Lines are parallel. No intersection.")
  }
  
  c1 = y1 - m1*x1
  c2 = y3 - m2*x3
  x = (c2-c1)/(m1-m2)
  y = m1*x + c1
  return(c(x,y))
}

# Function to generate actual vs predicted plot, plotted per panel
actualVsPredictedGrid <- function(x, mapping, priColor, secColor) {
  
  limits <- c(min(x$predicted, x$actual), max(x$predicted, x$actual))
  
  avpGrid <- ggplot2::ggplot(x, mapping) +
    ggplot2::geom_point(colour = priColor) +
    ggplot2::geom_line(stat = "smooth", method = "loess", alpha = 0.4, colour = priColor) +
    ggplot2::geom_abline(slope = 1, intercept = 0, linetype = 'dashed', colour = 'grey50') +
    ggplot2::xlim(limits) +
    ggplot2::ylim(limits) +
    ggplot2::facet_wrap( ~ panel, scales = 'free') +
    ggplot2::labs(x = "Predicted", y = "Actual", color = "Panel")
  
  return(avpGrid)
}

# Function to generate fitted vs residual plot, plotted per panel
residualsGrid <- function(x, mapping, priColor, secColor) {
  
  residGrid <- ggplot2::ggplot(x, mapping) +
    ggplot2::geom_point(colour = priColor) +
    ggplot2::geom_line(stat = "smooth", method = "loess", alpha = 0.4, colour = priColor) +
    ggplot2::geom_abline(slope = 0, intercept = 0, linetype = 'dashed', colour = 'grey50') +
    ggplot2::facet_wrap( ~ panel, scales = 'free') +
    ggplot2::labs(x = "Fitted", y = "Residuals", color = "Panel")
  
  return(residGrid)
}


# Function to generate the histogram of residuals, plotted per panel
histogramResidGrid <- function(x, priColor) {
  
  histResidPlot <- ggplot2::ggplot(x, ggplot2::aes(residuals)) +
    ggplot2::geom_histogram(bins = 20, color = 'grey90', fill = scales::alpha(priColor, 0.7)) +
    ggplot2::facet_wrap( ~ panel, scales = 'free') +
    ggplot2::xlab("Residuals") +
    ggplot2::ylab("Count")
  
  return(histResidPlot)
}

# # Function to generate actual vs predicted plot, coloured by panel
# actualVsPredictedPlot <- function(x, mapping, priColor, secColor) {
#   avpPlot <- ggplot(x, mapping) +
#     geom_point(colour = priColor) +
#     # geom_smooth(method = "loess", aes(colour=NULL), alpha = 0.2, color = alpha("blue",0.3)) +
#     geom_line(stat = "smooth", method = "loess", alpha = 0.3, colour = secColor) +
#     geom_abline(slope = 1, intercept = 0, linetype = 'dashed', colour = 'gray50') +
#     xlim(c(min(x$predicted, x$actual), 
#            max(x$predicted, x$actual))) +
#     ylim(c(min(x$predicted, x$actual), 
#            max(x$predicted, x$actual))) +
#     labs(y = "Actual", x = "Predicted", color = "Panel")
#   
#   return(avpPlot)
# }
# 
# 
# # Function to generate residual vs fitted plot, coloured by panel
# residualsPlot <- function(x, mapping, priColor, secColor) {
#   
#   residPlot <- ggplot(x, mapping) +
#     geom_point(colour = priColor) +
#     geom_smooth(method = "loess", aes(colour=NULL), alpha = 0.2, color = alpha(secColor)) +
#     # geom_line(stat = "smooth", method = "loess", alpha = 0.4) +
#     geom_abline(slope = 0, intercept = 0, linetype = 'dashed', colour = 'gray50') +
#     labs(x = "Fitted", y = "Residuals", color = "Panel")
#   
#   return(residPlot)
# }
# 
# 
# # Function to generate histogram of residuals in a single plot for all panels
# histogramResidPlot <- function(x, priColor, secColor) {
# 
#   histResidPlot <- ggplot(x, aes(residuals)) +
#     geom_histogram(bins = 20, color = secColor, fill = alpha(priColor, 0.7)) +
#     xlab("Residuals") +
#     ylab("Count")
# 
#   return(histResidPlot)
# }


# Function to generate the dotplots for random effect coefficients
caterpillarPlot <- function(x, title = "", priColor) {
  
  ord  <- unlist(lapply(x, order)) + rep((0:(ncol(x) - 1)) * nrow(x), each=nrow(x))
  
  coefDf <- data.frame(y=unlist(x)[ord],
                       ID=factor(rep(rownames(x), ncol(x))[ord], levels=rownames(x)[ord]),
                       ind=gl(ncol(x), nrow(x), labels=names(x))
  )
  
  catPlot <- ggplot2::ggplot(coefDf, ggplot2::aes(ID, y)) + ggplot2::coord_flip() +
    ggplot2::facet_wrap(~ ind, scales = "free_x") +
    ggplot2::xlab("Levels") + ggplot2::ylab("Random effects") +
    ggplot2::theme(legend.position="none") +
    ggplot2::geom_point(size = 1, colour=priColor) +
    ggplot2::ggtitle(title) +
    ggplot2::theme(plot.title = ggplot2:: element_text(hjust = 0.5, face = "bold", size = 16))
  
  return(catPlot)
}


# Generating plots for binomial regression
binomialPlots <- function(trueY, predY, positiveClass, priColor, secColor) {
  
  if(class(trueY) != 'factor') {
    stop('trueY needs to be of factor type')
  }
  
  rocObj <- pROC::roc(trueY, predY)
  thresh <- rocObj$thresholds[2:(length(rocObj$thresholds)-1)]
  sense <- rocObj$sensitivities[2:(length(rocObj$thresholds)-1)]
  specs <- rocObj$specificities[2:(length(rocObj$thresholds)-1)]
  plotData <- cbind(thresh, sense, specs)
  diff <- sense - specs
  i <- sum(diff>0)
  if(rocObj$thresholds[1]==-Inf) {
    len <- length(rocObj$thresholds)
    plotData <- rbind( c(0, rocObj$sensitivities[1], rocObj$specificities[1]), plotData)
    plotData <- rbind(plotData, c(1, rocObj$sensitivities[len], rocObj$specificities[len]))
    i <- i+1
  }
  
  plotData[which((-Inf)==plotData[,1]),1] = 0
  plotData[which(Inf==plotData[,1]),1] = 1
  if(i>0 && nrow(plotData)) {
    x1 <- x3 <- plotData[i,1]
    x2 <- x4 <- plotData[i+1,1]
    y1 <- plotData[i,2]
    y2 <- plotData[i+1,2]
    y3 <- plotData[i,3]
    y4 <- plotData[i+1,3]
    optThresh <- unname(intersection(x1, y1, x2, y2, x3, y3, x4, y4)[1])
  } else {
    optThresh <- thresh[1]
  }
  
  specs <- 1 - specs
  rocData <- data.frame(specs, sense)
  rocData <- rocData[rev(c(1:nrow(rocData))),]
  rocData <- rbind(c(0,0), rocData, c(1,1))
  auc <- round(rocObj$auc[1], 4)
  linePlot <- ggplot2::geom_line(data = rocData,ggplot2::aes(x = specs,y=sense),color=priColor, linetype="solid")
  rocPlot <- ggplot2::ggplot() + linePlot +
    ggplot2::ggtitle("ROC plot") + 
    ggplot2::xlab("(1 - Specificity)") + 
    ggplot2::ylab("Sensitivity") + 
    ggplot2::geom_line(ggplot2::aes(x,y), data=data.frame(x=rbind(0,1), y=rbind(0,1)), linetype="dotted") + 
    ggplot2::annotate("text",x = 0.6, y = 0.4, label = paste0("AUC \n ",auc), size = 7, color = "#337ab7") +
    ggplot2::theme(legend.position=c(0.8,0.8),
          legend.background = ggplot2:: element_rect(fill=scales::alpha('white', 0)),
          legend.direction = "vertical",
          plot.title = ggplot2:: element_blank(),
          axis.title=ggplot2:: element_text(size=14))
  
  sensiSpeciPlot <- ggplot2::ggplot(data.frame(plotData), ggplot2::aes(thresh)) + 
    ggplot2::geom_line(ggplot2::aes(y=sense, colour="sensitivity")) + 
    ggplot2::geom_line(ggplot2::aes(y=specs, colour="specifity")) + 
    ggplot2::xlab("Threshold") + 
    ggplot2::ylab("Sensitivity-Specificity values") + 
    ggplot2::ggtitle("Sensitivity-Specificity vs Threshold plot") + 
    ggplot2::theme(plot.title = ggplot2:: element_text(hjust = 0.5)) + 
    ggplot2::geom_vline(ggplot2::aes(xintercept=optThresh)) + 
    ggplot2::guides(colour=ggplot2::guide_legend(title="")) + 
    ggplot2::scale_color_manual(values=c(priColor, secColor)) +
    ggplot2::theme(legend.position=c(0.8,0.8),
          legend.background = ggplot2:: element_rect(fill=scales::alpha('white', 0)),
          legend.direction = "vertical",
          plot.title = ggplot2:: element_blank(),
          axis.title=ggplot2:: element_text(size=14))

  ## precision, recall, accuracy plots
  thseq <- seq(0.1,0.9 ,0.01)
  positiveClass <- ifelse(is.na(positiveClass), levels(trueY)[2], positiveClass)
  factorLabels <- if(levels(trueY)[1] == positiveClass) rev(levels(trueY)) else levels(trueY)
  metricTable <- data.frame(threshold = thseq, accuracy=rep(NA,length(thseq)), precision=rep(NA,length(thseq)), 
                            recall=rep(NA,length(thseq)), fscore=rep(NA,length(thseq)))
  
  for(th in thseq){
    predLablesForTh <- cut(predY, breaks=c(0, th, 1), labels=factorLabels, include.lowest = T)
    cmForTh <- caret::confusionMatrix(predLablesForTh, trueY, positive = factorLabels[2])
    metricTable[metricTable[,"threshold"]==th,"accuracy"] <- round(cmForTh$overall[[1]]*100,2)
    metricTable[metricTable[,"threshold"]==th,"precision"] <- round(cmForTh$byClass['Precision'][[1]]*100,2)
    metricTable[metricTable[,"threshold"]==th,"recall"] <- round(cmForTh$byClass['Recall'][[1]]*100,2)
    metricTable[metricTable[,"threshold"]==th,"fscore"] <- round(cmForTh$byClass['F1'][[1]]*100,2)
  }
  metricTableSubset <- metricTable[seq(1,nrow(metricTable),10),]
  
  accuracyPlot <- ggplot2::ggplot(metricTable,ggplot2::aes(x=threshold,y=accuracy),fill= priColor, alpha="0.2") + 
    ggplot2::geom_line(color = priColor, size = 1.5) + 
    ggplot2::scale_x_continuous(name = "thresholded to positive class",breaks = seq(0, 1, 0.1)) + 
    ggplot2::scale_y_continuous(name = "Accuracy (%)", limits = c(0, 100), breaks = seq(0, 100, 10)) + 
    ggplot2::geom_text(data=metricTableSubset, ggplot2::aes(x = threshold, y = accuracy, label = paste0(format(accuracy,digits=4),"%")), 
              hjust = 0.3, vjust = -1, size = 4,color = I(secColor)) +
    ggplot2::ggtitle("Accuracy @ k")
  
  precisionPlot <- ggplot2::ggplot(metricTable,ggplot2::aes(x=threshold,y=precision),fill= priColor,alpha="0.2") + 
    ggplot2::geom_line(color = priColor, size = 1.5) + 
    ggplot2::scale_x_continuous(name = "thresholded to positive class",breaks = seq(0, 1, 0.1)) + 
    ggplot2::scale_y_continuous(name = "Precision (%)", limits = c(0, 100), breaks = seq(0, 100, 10)) + 
    ggplot2::geom_text(data=metricTableSubset, ggplot2::aes(x = threshold, y = precision, label = paste0(format(precision,digits=4),"%")), 
              hjust = 0.3, vjust = -1, size = 4,color = I(secColor)) +
    ggplot2::ggtitle("Precision @ k")
  
  recallPlot <- ggplot2::ggplot(metricTable,ggplot2::aes(x=threshold,y=recall),fill= priColor,alpha="0.2") + 
    ggplot2::geom_line(color = priColor, size = 1.5) + 
    ggplot2::scale_x_continuous(name = "thresholded to positive class",breaks = seq(0, 1, 0.1)) + 
    ggplot2::scale_y_continuous(name = "Recall (%)", limits = c(0, 100), breaks = seq(0, 100, 10)) + 
    ggplot2::geom_text(data=metricTableSubset, ggplot2::aes(x = threshold, y = recall, label = paste0(format(recall,digits=4),"%")), 
              hjust = 0.3, vjust = -1, size = 4,color = I(secColor)) +
    ggplot2::ggtitle("Recall @ k")
  
  
  aocTable <- data.frame(Metric = c("Area Under Curve","Optimal threshold"), 
                         Value = c(round(auc, 4), round(optThresh, 4)), row.names = NULL)
  
  return(list(roc = rocPlot, ss = sensiSpeciPlot, precision = precisionPlot, recall = recallPlot, accuracy = accuracyPlot, 
              optThresh = optThresh, aocTable = aocTable))
}


## Download Report
downloadReport <- function(reactData, input, fileName){
  
  rmarkdown::render('Source/PanelRegressionReport.Rmd',
                    switch(input$report_format,
                           PrettyHTML = prettydoc::html_pretty(css = paste0(reactData$working_dir, "/Styles/pretty_styles.css")),
                           HTML = rmarkdown::html_document(css = paste0(reactData$working_dir,"/Styles/styles.css") ,toc=TRUE, toc_float=TRUE)
                    ), 
                    output_dir = paste0(reactData$working_dir,"/Downloads/"), 
                    output_file = fileName,
                    params = list(
                      workingDir = reactData$working_dir,
                      reactData = reactData,
                      input = input
                    )
  )
}

handleMissingValues <- function(data, remove=T, y=NULL)
{
  missN <- nrow(data[rowSums(is.na(data)) > 0,])
  if(missN > 0)
  {
    if(!remove)
      missValueMsg <- paste0("WARNING: There are ", missN,
                             " row(s) with missing values in the data set. ","Because of this, there is 
                             a possibility that models may misbehave. Please use the 'Data Wrangling Brick' 
                             to create your analytical data set.")
    else
      missValueMsg <- paste0("NOTE: There are ", missN,
                             " row(s) with missing values in the data set, which have been removed.")
  }else
  {
    missValueMsg <- ""
  }
  if(remove)
    data <- na.omit(data)
  return(list(data=data, mssg=missValueMsg, missTable=NULL))
}