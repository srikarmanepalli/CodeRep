#### Package Variables used in the brick ####
source("Source/panelRegressionUtils.R")
loadGlobals()

### Common for all the bricks
basicPackages <- c("rjson","shinyFiles", "pander","rmarkdown", "shinyjs", "colourpicker", "shiny", "shinyBS")


PackageDependencyList <- function(packageList){
  
  if(class(packageList) != "character"){
    packageList <- as.character(packageList)
  }
  
  if(length(packageList) == 0){
    stop('input parameter is empty')
  }
  
  # Create a graph object to containing package dependency hierarchy
  dependency.check <- miniCRAN::makeDepGraph(packageList, suggests = FALSE, includeBasePkgs = FALSE)
  
  # Iterates over each element of the object packageList and gives out the individual package dependencies for each of these
  # Elements of packageList 
  result <- list()
  for(i in 1:length(packageList)){
    result[[i]] <- (igraph::topo_sort(dependency.check))}
  
  # For each element in the list, numbers are replaced with package names, remove NAs and reverse the order to get the correct order
  result <- lapply(result, function(x){
    x <- igraph::as_ids(x)
  })
  result <- Reduce(c, result) #append all the lists into one list
  result <- result[!duplicated(result)] #remove duplicates
  
  return(result) 
}


basicPackagesList <- PackageDependencyList(basicPackages)
packagesList <- PackageDependencyList(packages)
dbPackagesList <- PackageDependencyList(dbPackages)
packageDependencies <- list('basicPackagesList'= basicPackagesList, 'packagesList' = packagesList, 'dbPackagesList' = dbPackagesList)
saveRDS(packageDependencies , "Source/packagesList.RDS")

requiredPackages <- unique(unlist(packageDependencies))
installedPackages <- as.data.frame(installed.packages())
installedPackages <- installedPackages[!duplicated(installedPackages$Package), c(1,3)]
installedPackages <- installedPackages[which(installedPackages$Package %in% requiredPackages),]
rownames(installedPackages) <- NULL
jsonlite::write_json(installedPackages, "Source/packageVersion.json")



