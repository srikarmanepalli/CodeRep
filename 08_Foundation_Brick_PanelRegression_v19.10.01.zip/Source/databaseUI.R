
databaseUI<- function(input,output,session){
  connectionObj <<- NULL
  dbChoices <<- c(SQLite = "sqlite_db", MySQL = "mysql_db", 
                  PostgreSQL = "postgres", Oracle = "oracle", `SQL server` = "sql_server", 
                  Teradata = "teradata", Netezza = "netezza", Hive = "hive", 
                  Other = "other")
  odbcDbChoices <<- c(Hive = "hive",Teradata = "teradata", `SQL server` = "sql_server", Other = "other")
  
  
  
  output$dbUI<- renderUI({
    fluidRow(
      
      column(4,radioButtons("connectionMethod", "Choose connection method",choices=c("JDBC"="jdbc","ODBC"="odbc"),selected="jdbc",inline=TRUE))
      ,column(4,radioButtons("credMethod", "Choose login method",choices=c("Credentials"="cred","JDBC String"="jdbcString"),selected="cred",inline=TRUE))
      ,column(3,align="right",tags$div(HTML('<b>Config:</b>')),actionButton('loadConfig','Load'),actionButton('saveConfig','Save'))
      ,tags$br()
      ,div(id="jdbcSelect",column(12,selectInput('dbButton1','Select Database',choices=dbChoices,selected = 'postgres')))
      # ,div(id="odbcSelect",column(12,selectInput('dbButton2','Select Database',choices=odbcDbChoices,selected = 'postgres')))
      ,div(id='sqlitePath',column(12,textInput('dbName1','Enter Complete Path to Database')))
      ,div(id='dsnString',column(12,textInput('connectionString1','DSN')))
      ,div(id="loadSettings",column(4,textInput('dbHost','Host',value='', placeholder= 'example@server.com [OR] IP Address'))
           ,column(2,textInput('dbPort','Port'))
           ,column(5, textInput('dbName','DB Name',value='', placeholder = 'Database Name')))
      ,div(id='JDBCConnString',style="display:none;",column(12,tagList(textInput('connectionString','Enter JDBC Connection String'),tags$p(HTML('E.g. jdbc:mysql://127.0.0.1:5432/mydatabase')))))
      ,div(id='loadSettings2',column(6,textInput('dbUsername','Username',value='', placeholder = 'Username')),column(6,passwordInput('dbPassword','Password',value='')))
      ,div(id='driverOptionsDiv',column(12,checkboxInput('driverOptions','Load JDBC drivers manually')))
      ,div(id='manualDrivers',column(6,textInput('driverLocation','JDBC Driver Location')
                                     ,tags$div(HTML("E.g. C:/Users/Admin/Desktop/Folder_containing_jars/<br/> Use '/' for specifying location.")))
           ,column(6,textInput('driverClass','JDBC Driver Class')
                   ,tags$div(HTML('E.g. oracle.jdbc.OracleDriver'))))
      ,column(12,checkboxInput(inputId = 'useSsl',label='Use SSL Encryption',F))
      ,div(id='sslContent',column(6,fileInput('certification','Choose certification',multiple = F)),column(6,passwordInput('sslPassword','SSL Password',value='')))
      ,column(12,align='left',actionButton('srcSubmitButton2','Connect'))
      ,column(12,align='left',uiOutput('UIconn'))
      ,column(12,align='left',uiOutput('connIndicatorUI'))
      ,column(12,textInput('tableName1','Enter Primary Table Name/Query (Write table name or query space seperated by table name)',value='', placeholder="Primary Table Name"))
      ,column(12,actionButton('submitTable','Submit'))  
      )
  })
  
  observeEvent(input$srcSubmitButton2,{
    
    connectionParams <<- list( #---Store the connection paramters in global variable
      dbButton1 = input$dbButton1,
      dbName = input$dbName,
      dbName1 = input$dbName1,
      dbHost = input$dbHost,
      dbPort = as.integer(input$dbPort),
      dbUsername = input$dbUsername,
      dbPassword = input$dbPassword,
      dbTable = input$dbTable,
      dbDriverLocation = input$driverLocation,
      dbDriverClass = trimws(input$driverClass),
      driverOptions = input$driverOptions,
      certification = input$certification$datapath,
      useSsl=input$useSsl,
      sslPassword = input$sslPassword,
      connectionString = trimws(input$connectionString),
      connectionString1 = trimws(input$connectionString1),
      connectionMethod = trimws(input$connectionMethod),
      credMethod = input$credMethod)
    
    
    
    
    
    
    #print('Sourcing from Database')
    
    con <- connect(connectionParams)
    connFlag <<- TRUE
    
    
    
    
    if(is.null(con[[1]])){
      output$connIndicatorUI <- renderUI({tags$p(paste0('Error in Connection: ',con[[2]]),style="color:red;")})
      showNotification(con[[2]],type='error')
      return()
    }
    output$connIndicatorUI <- renderUI({tags$p('Connection Established',style="color:green;")})
    showNotification("Connection Established")
    connectionObj <<- con[[1]]
    
  })
  
  output$connIndicatorUI <- renderUI({})
  
  #--Close db connection on closing window--#
  observe({  
    js_string <- 'confirm("Are You Sure?");'
    session$sendCustomMessage(type='jsCode', list(value = js_string))
    
    cancel.onSessionEnded <- session$onSessionEnded(function() {
      
      if(!is.null(connectionObj)){
        #print('Dropping qcTempTable and qcTempTableManipulated Tables')
        
        #print('Closing DB connections')
        dbDisconnect(conList$con)
      }
    })
  })
  
  ##-- Update dbName input for oracle 
  observeEvent(input$dbButton1,{
    dbName <- input$dbButton1
    if(dbName=='oracle'){
      updateTextInput(session,'dbName','Service Name Or SID')
    } else {
      updateTextInput(session,'dbName','DB Name')
    }
  })
  observeEvent(input$connectionMethod,{
    connectionMethod <- input$connectionMethod
    if(connectionMethod=='jdbc'){
      updateSelectInput(session,'dbButton1','Select Database',choices=dbChoices,selected = 'postgres')
    } else {
      updateSelectInput(session,'dbButton1','Select Database',choices=odbcDbChoices,selected = 'hive')
    }
  })
  observeEvent(input$saveConfig,{
    
    configList <- list(
      dbButton1=input$dbButton1,
      dbName = input$dbName,
      dbName1 = input$dbName1,
      dbHost = input$dbHost,
      dbPort = as.integer(input$dbPort),
      dbUsername = input$dbUsername,
      dbDriverLocation = input$driverLocation,
      dbDriverClass = trimws(input$driverClass),
      driverOptions = input$driverOptions,
      connectionString = trimws(input$connectionString),
      connectionString1 = trimws(input$connectionString1),
      connectionMethod = trimws(input$connectionMethod)
      
    )
    saveRDS(configList,'Downloads/DBconfig.rds')
    showNotification('Configuration Saved')
  })
  
  #____Load saved config____#
  observeEvent(input$loadConfig,{
    #print("Loading last saved connection configuration")
    
    if(!file.exists('Downloads/DBconfig.rds')){
      showNotification('No Existing Configuration File Found!',type='error')
      return()
    }
    config <- readRDS('Downloads/DBconfig.rds')
    #print(c("Config: ", config))
    #print(input$loadConfig)
    # print("##############################################")
    # print(input$connectionMethod)
    # updateRadioButtons(session, 'connectionMethod', "Choose a connection method", 
    # choices = c("JDBC", "ODBC"), selected=toupper(config$connectionMethod))
    #print(input$connectionMethod)
    updateSelectInput(session,'dbButton1','Select Database',choices=showChoices(config$connectionMethod),selected=config$dbButton1)
    updateTextInput(session,'dbHost','Host',value=config$dbHost)
    updateTextInput(session,'dbPort','Port',value=config$dbPort)
    if(config$dbName=='oracle'){
      updateTextInput(session,'dbName','Serive Name Or SID',value=config$dbName)
    }
    else{
      updateTextInput(session,'dbName','DB Name',value=config$dbName)
    }
    updateTextInput(session,'dbUsername','Username',value=config$dbUsername)
    updateTextInput(session,'dbName1','Enter Complete Path to Database',value=config$dbName1)
    updateTextInput(session,'connectionString','Enter JDBC Connection String',value=config$connectionString)
    updateTextInput(session,'driverLocation','JDBC Driver Location',value=config$dbDriverLocation)
    updateTextInput(session,'connectionString1','DSN',value=config$connectionString1)
    updateTextInput(session,'driverClass','JDBC Driver Class',value=config$dbDriverClass)
    
    
    if(length(config$dbDriverClass)!=0)
      updateCheckboxInput(session,'driverOptions',value=1)
    updateTextInput(session,'dbPassword','Password',value='')
    showNotification('Configuration Loaded')
  })
  
}




dbExistsTableWrapper <- function(connectionObj, name, connDb,i){
  flag <- FALSE
  if(name=='') return(flag)
  alias <- LETTERS[i]
  conList <<- list(con=connectionObj,table=name,db=connDb)
  
  path <- NULL
  data <- name
  
  head <- dbFetchTopWrapper(conList)
  print(head)
  if(!is.null(head))
    flag <- TRUE
  return(flag)
}

dbFetchTopWrapper <- function(conList){
  
  fn <- function(){
    tryCatch(dbFetchTop(conList)
             ,error=function(e){message(e[1])})
  }
  dat <- fn()
}

dbTableSelectQuery <- function(conList){
  
  if(grepl(" ",conList$table)){
    
    return(gsub("\\s*\\w*$", "",conList$table))
  }
  else
  {
    query <- switch(conList$db#connectionParams$dbButton1
                    ,'oracle'={
                      paste('select * from',conList$table)
                    }
                    ,'mysql_db' = paste('select * from', conList$table)
                    ,'postgres' = paste('select * from',conList$table)
                    ,'sql_server' = paste('select * from', conList$table)
                    ,'teradata' = paste('select * from', conList$table)
                    ,paste('select * from', conList$table)
    )
    print(query)
    return(query)}
}

dbTableAll <- function(conList){
  query <- dbTableSelectQuery(conList)
  dbSendQuery(conList$con,query)
}

dbFetchAll <- function(conList){
  con <- conList$con
  if(!class(con)=="SQLiteConnection") clearResults(conList$con)
  res <- dbTableAll(conList)
  dat <- dbFetch(res)
  if(!class(con)=="SQLiteConnection") clearResults(conList$con)
  dat
}

dbTableTopQuery <- function(conList){
  
  n=10
  if(grepl(" ",conList$table)){
    return(gsub("\\s*\\w*$", "",conList$table))
  }
  else
  {
    query <- switch(conList$db#connectionParams$dbButton1
                    ,'oracle'={
                      paste('select * from',conList$table,' where rownum <=',n)
                    }
                    ,'mysql_db' = paste('select * from', conList$table,'limit',n)
                    ,'postgres' = paste('select * from',conList$table,'limit',n)
                    ,'sql_server' = paste('select * from', conList$table,'limit',n)
                    ,'teradata' = paste('select top',n,' * from', conList$table)
                    ,paste('select top',n,' * from', conList$table)
    )
    print("query")
    return(query)}
}


dbTableTop <- function(conList){
  
  query <- dbTableTopQuery(conList)
  
  dbSendQuery(conList$con,query)
}

dbFetchTop <- function(conList){
  
  con <- conList$con
  if(!class(con)=="SQLiteConnection") clearResults(conList$con)
  res <- dbTableTop(conList)
  dat <- dbFetch(res)
  if(!class(con)=="SQLiteConnection") clearResults(conList$con)
  dat
}
showChoices <- function(connectionMethod){
  if(tolower(connectionMethod == "jdbc")){
    return(dbChoices)
  }else{
    return(odbcDbChoices)
  }
} 

connect <- function(cParams){
  
  dbButton1 <- cParams$dbButton1
  dbName <- cParams$dbName
  dbName1 <- cParams$dbName1
  dbHost <- cParams$dbHost
  dbPort <- as.integer(cParams$dbPort)
  dbUsername <- cParams$dbUsername
  dbPassword <- cParams$dbPassword
  dbTable <- cParams$dbTable
  dbDriverLocation <- cParams$dbDriverLocation
  dbDriverClass <- trimws(cParams$dbDriverClass)
  driverOptions <- cParams$driverOptions
  certification <- cParams$certification
  sslPassword <- cParams$sslPassword
  useSsl <- cParams$useSsl
  connectionString <- trimws(cParams$connectionString)
  connectionString1 <- trimws(cParams$connectionString1)
  connectionMethod <- trimws(cParams$connectionMethod)
  credMethod <- cParams$credMethod
  
  if(tolower(connectionMethod) == "jdbc"){
    
    #print("Trying to establish JDBC connection...")
    
    tryCatch({
      if(driverOptions==1){
        cp <- list.files(dbDriverLocation, pattern = "[.]jar", full.names=TRUE, recursive=TRUE)
        
        if(useSsl && dbButton1=='hive'){
          .jaddClassPath(cp)
          driver <- JDBC("org.apache.hive.jdbc.HiveDriver", dbDriverClass)
        }else{
          driver <- JDBC(dbDriverClass,cp,identifier.quote='`')
        }
      } else {
        driver <-  switch(dbButton1
                          ,'sqlite_db'= RSQLite::SQLite()
                          ,'mysql_db'= RMySQL::MySQL()
                          ,'postgres'= RPostgreSQL::PostgreSQL()
                          ,NULL
        )
      }
      
      if(is.null(driver)){
        #showNotification('JDBC driver not available. Please provide the location of JDBC driver and Class manually')
        return(list(NULL,'JDBC driver not available. Please provide the location of JDBC driver and Class manually'))
      }
      
      #print('Loading DB driver')
      
      my_db <- switch(dbButton1
                      ,'sqlite_db' = dbConnect(driver,dbName1)
                      ,'mysql_db' = {
                        if(credMethod=='jdbcString'){
                          str <- paste0("dbConnect(driver,url='",connectionString,"',user='",dbUsername,"',password='",dbPassword,"')")
                          
                          con <- eval(parse(text=str))
                          con
                        }
                        else
                          dbConnect(driver,url='jdbc:mysql://',
                                    port=dbPort,host=dbHost,dbname=dbName,password=dbPassword,user=dbUsername)}
                      ,'postgres' = {
                        if(credMethod=='jdbcString'){
                          str <- paste0("dbConnect(driver,url='",connectionString,"',user='",dbUsername,"',password='",dbPassword,"')")
                          
                          con <- eval(parse(text=str))
                          con
                        }
                        else
                          dbConnect(driver,paste0("jdbc:postgresql://",''),
                                    port=dbPort,host=dbHost,dbname=dbName,password=dbPassword,user=dbUsername)}
                      ,'sql_server' = {
                        if(credMethod=='jdbcString'){
                          str <- paste0("dbConnect(driver,url='",connectionString,"',user='",dbUsername,"',password='",dbPassword,"')")
                          
                          con <- eval(parse(text=str))
                          con
                        }
                        else
                          dbConnect(drv=driver,url=paste0('jdbc:sqlserver://',dbHost,":",dbPort),user=dbUsername,password=dbPassword)
                        
                      }
                      ,'teradata' = {
                        if(credMethod=='jdbcString'){
                          str <- paste0("dbConnect(driver,url='",connectionString,"',user='",dbUsername,"',password='",dbPassword,"')")
                          
                          con <- eval(parse(text=str))
                          con
                        }
                        else
                          dbConnect(driver,paste0('jdbc:teradata://',dbHost,',DATABASE=',dbName), password=dbPassword,user=dbUsername)}
                      ,'oracle'= {
                        #require(ROracle)
                        # connect.string <- paste("(DESCRIPTION=","(ADDRESS=(PROTOCOL=tcp)(HOST=", dbHost, ")(PORT=", dbPort, "))"
                        #                       ,"(CONNECT_DATA=(SID=", sid, ")))", sep = "")
                        #con1 <- dbConnect(driver, user = dbUsername, password = dbPassword, dbname=connect.string)
                        print(connectionString)
                        if(credMethod=='jdbcString'){
                          str <- paste0("dbConnect(driver,url='",connectionString,"',user='",dbUsername,"',password='",dbPassword,"')")
                          print(str)
                          con <- eval(parse(text=str))
                          con
                        }
                        else{
                          con1 <- dbConnect(driver, url=paste0("jdbc:oracle:thin:@//",dbHost,":",dbPort,"/",dbName), dbUsername, dbPassword)
                          
                          con1}
                      }
                      ,'netezza'= {
                        if(credMethod=='jdbcString'){
                          str <- paste0("dbConnect(driver,url='",connectionString,"',user='",dbUsername,"',password='",dbPassword,"')")
                          
                          con <- eval(parse(text=str))
                          con
                        }
                        else
                          dbConnect(driver, paste0("jdbc:netezza://",dbHost,":",dbPort,"//",dbName), user=dbUsername, password=dbPassword)
                      }
                      ,'hive'= {
                        
                        if(credMethod=='jdbcString'){
                          str <- paste0("dbConnect(driver,url='",connectionString,"',user='",dbUsername,"',password='",dbPassword,"')")
                          
                          con <- eval(parse(text=str))
                          con
                        }
                        else{
                          if(useSsl){
                            connectionhost <- paste0('jdbc:hive2://',dbHost,':',dbPort,"/",dbName)
                            
                            SSLPath <- paste0(certification)
                            connectionString = paste0(connectionhost,';ssl=true;sslTrustStore=',SSLPath,';trustStorePassword=', sslPassword)
                            
                            #Final Connection String
                            con <- dbConnect(driver,connectionString ,dbUsername, dbPassword)
                            
                          }
                          else{
                            connectionhost <- paste0('jdbc:hive2://',dbHost,':',dbPort,"/",dbName)
                            str <- paste0("dbConnect(driver,url='",connectionhost,"',user='",dbUsername,"',password='",dbPassword,"')")
                            con <- eval(parse(text=str))
                          }
                          
                          con}
                      }
                      ,'other'= {
                        str <- paste0("dbConnect(driver,url='",connectionString,"',user='",dbUsername,"',password='",dbPassword,"')")
                        
                        con <- eval(parse(text=str))
                        con
                      }
      )
      
      #print("Success!")
      return(list(my_db,''))
    }
    ,error = function(e){
      #showNotification(paste('DB error:',e[1]),type='error');
      message(e[1]);
      return(list(NULL,paste('DB error:',e[1])))
    })
  }else{
    tryCatch({
      
      #print('Trying to establish ODBC connection...')
      
      my_db <- switch(dbButton1,
                      'hive'= {
                        con <- DBI::dbConnect(odbc::odbc(),
                                              dsn = connectionString1,
                                              Host   = dbHost,
                                              Schema = dbName,
                                              UID    = dbUsername,
                                              PWD    = dbPassword,
                                              Port   = dbPort)
                        con
                      }
                      ,'teradata'= {
                        # print(connectionString1)
                        con <- DBI::dbConnect(odbc::odbc(),
                                              dsn = connectionString1,
                                              Host   = dbHost,
                                              Schema = dbName,
                                              Port   = dbPort)
                        
                        con
                      }
                      ,'sql_server'= {
                        con <- DBI::dbConnect(odbc::odbc(),
                                              dsn = connectionString1,
                                              Host   = dbHost,
                                              Schema = dbName,
                                              UID    = dbUsername,
                                              PWD    = dbPassword)
                        con
                      }
                      ,'other'= {
                        str <- paste0("dbConnect(odbc::odbc(), dsn =\"",as.character(connectionString1),"\", uid =\"",dbUsername, "\", pwd =\"",dbPassword,"\")")
                        
                        con <- eval(parse(text=str))
                        con
                      }
      )
      #print("Success!")
      return(list(my_db,''))
    }
    ,error = function(e){
      #showNotification(paste('DB error:',e[1]),type='error');
      message(e[1]);
      return(list(NULL,paste('DB error:',e[1])))
    }
    )
  }
}


clearResults <- function(con){
  if(class(con)=='SQLiteConnection') return()
  if(is.null(DBI::dbGetInfo(con)$odbcdriver)){
    if(dbResultLen(con)){
      dbClearResult(dbListResults(con)[[1]])
    }
  }else{
    return()
  }
}


dbResultLen <- function(con){
  if(is.null(DBI::dbGetInfo(con)$odbcdriver)){
    return(length(dbListResults(con)))
  }
  else{
    return()
  }
}

