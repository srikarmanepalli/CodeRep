#######################################################################################################################
# Package Installation Script
# Vivek 
# Version 1.05
# Script for easy installation of Foundation Bricks
# * Added script for perfroming package dependency check
#######################################################################################################################
#######################################################################################################################
# Function to write the packages whose installation failed to a file
# Input :
#         installationFailedPackages : list of packages whose installation failed 
#######################################################################################################################
writeInstallatioFailedPackages <-function(installationFailedPackages){
  if(!is.null(installationFailedPackages) && length(installationFailedPackages)>0){
    misspackages <- paste0(installationFailedPackages, collapse= "','")
    messagehead <- "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:"
    installationFailedPackages <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"),messagehead, "\r\ninstall.packages(c('", misspackages, "'), repos = 'http://cloud.r-project.org/')")
    write(installationFailedPackages, paste0("InstallationFailedPackages.txt"), sep="\n")
  }
} 
#######################################################################################################################
# Function to load the packages(basicPackages,packages and dbPackages) which are installed and install which are not present, 
# also check for java version, architecture and check if Java home is set and give appropriate messages.
# Output :
#         dbWarning : initiallyempty but contains suitable message if java related issues occur 
#######################################################################################################################
loadMains <- function(brickName = ""){
  ##hard check for ggplot versionb
  if("ggplot2" %in% installed.packages()[,1] && packageVersion("ggplot2")=='2.2.1.9000') {
    remove.packages("ggplot2")
  }
  
  ##this section is to load basic packages,packages and dbpackages
  installationFailedPackages <<- c()
  packageDependencies <- readRDS("Source/packagesList.RDS")
  basicPackages <- packageDependencies$basicPackagesList
  tryCatch({
    packageInstallStatus <- loadpackage(basicPackages)
    if(!is.null(packageInstallStatus) && packageInstallStatus!=TRUE){
      installationFailedPackages <<- c(installationFailedPackages, packageInstallStatus)
    }
  }, error = function(e){
    print(e)
  })
  packages <- packageDependencies$packagesList
  dbPackages <- packageDependencies$dbPackagesList
  tryCatch({
    packageInstallStatus <- loadpackage(packages)
    if(!is.null(packageInstallStatus) && packageInstallStatus!=TRUE){
      installationFailedPackages <<- c(installationFailedPackages, packageInstallStatus)
    }
  },error=function(e){
    saveRDS(e, "Downloads/packagesError.RDS")
  })
  
  # Check JAVA version
  minJavaVersion <- "1.8"
  javaVersion <- CheckJavaVersion(minJavaVersion)
  # Check JAVA architecture
  matchArchitechture <- isJavaRMatch()
  dbWarning <- ""
  if(javaVersion == TRUE && matchArchitechture == TRUE && base::Sys.getenv("JAVA_HOME") != ""){
    tryCatch({
      packageInstallStatus <- loadpackage(dbPackages)
      if(!is.null(packageInstallStatus) && packageInstallStatus!=TRUE){
        installationFailedPackages <- c(installationFailedPackages, packageInstallStatus)
      } 
    },error=function(e){
      dbWarning <- str(e)
      saveRDS(e, "Downloads/dbPackagesError.RDS")
    })
  } else if(javaVersion == TRUE && matchArchitechture == TRUE && base::Sys.getenv("JAVA_HOME") == ""){
    dbWarning <- "the environment variable 'JAVA_HOME' needs to be set to the path where Java is installed"
  } else if(javaVersion == TRUE && matchArchitechture == FALSE && base::Sys.getenv("JAVA_HOME") == ""){
    dbWarning <- "the environment variable 'JAVA_HOME' needs to be set to the path where Java is installed"
  } else if(javaVersion == FALSE && matchArchitechture == TRUE){
    dbWarning <-base::paste0("The installed Java version on the system is less than the minimum version required (Java ", minJavaVersion, ")")
  } else if(javaVersion == TRUE && matchArchitechture == FALSE){
    dbWarning <-"Java and R architectures on this system doesn't match. "
  }else if(javaVersion == FALSE && matchArchitechture == FALSE){
    dbWarning <-"Java is not installed on the system"
  } else {
    dbWarning <-base::paste0("Install minimum Java version (>", minJavaVersion, ") that matches the R architecture on this machine")
  }  
  # write the failed packages to file
  ##ONLY FOR TEXT MINING WE DONOT CALL THIS FUNCTION AS IT TAKES CARE OF NON CRAN PACKAGES AS WELL FOR WHICH WE DO IT IN LOAD MAINS SECTIOn
  # writeInstallatioFailedPackages(installationFailedPackages)
  if(brickName==""){
    writeInstallatioFailedPackages(installationFailedPackages) 
  }else{
    writeInstallationNonCranPackages(dbWarning)
  }
  return(dbWarning)
} 

#######################################################################################################################
# Function to check if the installed version of Java is 1.8 to match system requirements of 'rJava' Package
# Inputs :
#     verbose: Set to FALSE by default. Else, if set as TRUE, returns additional details about 
#              version of Java and R which has been called inside the function
#     minJavaVersion: minimum Java version required
# 
# Output : Logical TRUE/FALSE output
#     TRUE: If the installed version of Java is 1.8
#     FALSE: If the installed version of Java is not 1.8     
#######################################################################################################################
CheckJavaVersion <- function(minJavaVersion, verbose = F){
  tryCatch({
    OSType <- Sys.info()['sysname']
    systemInfo <- system("java -version")
    if(systemInfo == 127 | systemInfo == 1){
      return(FALSE)
    }else if(systemInfo == 0){
      sysinfo <- system2("java", "-version", stdout = 'stdout.txt', stderr = 'stderr.txt')
      sysinfo <- readLines('stderr.txt')
      sysinfo <- paste(sysinfo,collapse = " ")
      sysinfo <- substr(sysinfo,stringr::str_locate(sysinfo,'version')[2]+3,stringr::str_locate(sysinfo,'version')[2]+5)
    }
    if(verbose == T){
      base::system("java -version")
    }
    if(file.exists('stderr.txt')){
      file.remove("stderr.txt")
    }
    if(file.exists('stdout.txt')){
      file.remove("stdout.txt")
    }
    # Check if the version of Java is 1.8
    if(sysinfo >= minJavaVersion){
      return(TRUE)
    }else{
      warning('minimum version requirements for Java not met')
      return(FALSE)
    }
  }, error = function(e){
    warning(e)
    return(FALSE)
  }, warning = function(e){
    warning(e)
    return(FALSE)
  })
}

#######################################################################################################################
# Function to check if the installed version of R is 3.4.4 to match requirements for Foundation Bricks
# Inputs : 
#     minVersion: Minimum R's version  
# 
# Output : 
#     returns R version if it's 3.4.4
#######################################################################################################################


RVersionCheck <- function(minVersion) {
  result <- strsplit(R.Version()$version.string, " ")[[1]][3]
  
  if(result < minVersion){
    warning("minimum version requirement of r not met")
    return(FALSE)
  }else{
    return(TRUE)
  }
}

#######################################################################################################################
# Function to match architecture build of R and java installled on a system(32/64-bit) 
# Inputs: 
#     verbose: Set to FALSE by default. Else, if set as TRUE, returns additional details about 
#              version of Java and R which has been called inside the function
# 
# Output: Logical TRUE/FALSE output
#     TRUE: If the architecture of both R and Java matches(32/64-bit)
#     FALSE: If the architecture of both R and Java doesn't match(32/64-bit)     
#######################################################################################################################

isJavaRMatch <- function(){
  OSType <- Sys.info()['sysname']
  rArch <- R.Version()
  rArch <- substr(rArch$arch, nchar(rArch$arch)-1, nchar(rArch$arch))
  if(rArch == "86"){
    rArch<-"32"
  }
  tryCatch({
    javaArchD <- system(paste0('java -D', rArch, ' -version'))
    javaArch <- system(paste0('java -d', rArch, ' -version'))
    if(javaArch == 0 | javaArchD == 0){
      return(TRUE)
    }else{
      return(FALSE)
    }
  }, error = function(e){
    warning("Architecture for the installed Versions of R and java don't match") 
    return(FALSE)
  }, warning= function(e){
    warning("Architecture for the installed Versions of R and java don't match") 
    return(FALSE)
  })
}


#######################################################################################################################
# Function which gives out a list of packages to be installed as dependencies during package instalation
# Inputs :
#     packageName: The package of interest
#     reqVersion: The required version of the package of interest 
#
# Output : 
#     A logical TRUE/FALSE output
#     TRUE: If version requirements have been met
#     FALSE: If version requirement are not met
#######################################################################################################################

checkPackageversion <- function(packageName, reqVersion){
  if(packageVersion(packageName) != reqVersion){
    warning(paste0("Version requirement of '", packageName, "' package not met. Version '", reqVersion, "' is required."))
    return(FALSE)
  }else{
    return(TRUE)
  }
}

#######################################################################################################################
# Function which gives out a list of packages to be installed as dependencies during package instalation
# Inputs :
#     packageList: A list of packages
#
# Output : 
#     The list of dependent packages which is required to be installed before the list of input packages
#######################################################################################################################

PackageDependencyList <- function(packageList){
  
  if(class(packageList) != "character"){
    packageList <- as.character(packageList)
  }
  
  if(length(packageList) == 0){
    stop('input parameter is empty')
  }
  
  # Create a graph object to containing package dependency hierarchy
  dependency.check <- miniCRAN::makeDepGraph(packageList, suggests = FALSE, includeBasePkgs = FALSE)
  
  # Iterates over each element of the object packageList and gives out the individual package dependencies for each of these
  # Elements of packageList 
  result <- list()
  for(i in 1:length(packageList)){
    result[[i]] <- (igraph::topo_sort(dependency.check))}
  
  # For each element in the list, numbers are replaced with package names, remove NAs and reverse the order to get the correct order
  result <- lapply(result, function(x){
    x <- igraph::as_ids(x)
  })
  result <- Reduce(c, result) #append all the lists into one list
  result <- result[!duplicated(result)] #remove duplicates
  
  return(result) 
}


#######################################################################################################################
# Function to load and install packages from a list of packages
# Ref: https://stackoverflow.com/questions/8175912/load-multiple-packages-at-once 
# Inputs: 
#     packageList: Variable to where a list of packages have been saved
# 
# Output: Logical TRUE/FALSE output
#     TRUE: If all the packages' from the list was installed and loaded successfully against each package's name
#     FALSE: If all/one of the packages' from the list couldn't be instaled and loaded successfully 
#            against each one's name   
#######################################################################################################################

loadpackage <- function(packageList){
  # #Extracts the names of all the packages from the installed.packages
  # toInstallPackages <- packageDepList[!(packageDepList %in% installed.packages()[, "Package"])]
  failedPackages <- c()
  if(is.null(packageList) || length(packageList)==0)
    return(NULL)
    #Installs and loads packages not there in installed.packages
  for(i in 1:length(packageList)){
    if(!(packageList[i] %in% installed.packages()[,1]) == TRUE){
      install.packages(packageList[i], dependencies = FALSE, repos = "http://cloud.r-project.org/")
    }
    if(!(packageList[i] %in% installed.packages()[,1]) == TRUE){
      warning(paste0(packageList[i], ": installation failed"))
      failedPackages <- c(failedPackages, packageList[i])
    }
  }
  if(length(failedPackages)>0){
  return(failedPackages)
  }
  else{
    return(TRUE)
  }
}
#######################################################################################################################
#######################################################################################################################
# This function is called only in TEXT MINING BRICK
# Function to check for NON-CRAN Packages, write the packages along with CRAN whose installation failed to a file
#######################################################################################################################
writeInstallationNonCranPackages <-function(dbWarning){
  #trying to install non cran packages (openNLPModels.en and RDRPOSTagger)
  installationFailedOpenNLPModels<<-FALSE
  installationFailedRDRPOSTagger<<-FALSE
  tryCatch({
    if(!("openNLPmodels.en" %in% utils::installed.packages()[,1])){
      utils::install.packages("openNLPmodels.en", repos = "http://datacube.wu.ac.at/" , type = "source")
      if(!("openNLPmodels.en" %in% utils::installed.packages()[,1])){
        installationFailedOpenNLPModels<<-TRUE
      }  
    }
  },error=function(e){
    installationFailedOpenNLPModels<<-TRUE
  })
  tryCatch({
    if(!("RDRPOSTagger" %in% utils::installed.packages()[,1])){
      utils::install.packages('RDRPOSTagger', repos ='http://www.datatailor.be/rcube', type = 'source',INSTALL_opts = '--no-multiarch')
      if(!("RDRPOSTagger" %in% utils::installed.packages()[,1])){
        installationFailedRDRPOSTagger<<-TRUE
      }  
    }
  },error=function(e){
    installationFailedRDRPOSTagger<<-TRUE
  })
  tryCatch({
    if(!("wordVectors" %in% utils::installed.packages()[,1])){
      devtools::install_github('bmschmidt/wordVectors')
      if(!("wordVectors" %in% utils::installed.packages()[,1])){
      }
    }
  },error=function(e){
    warning(e)
  },warning=function(e){
    warning(e)
  })
  # DownloadCoreNLP
  tryCatch({
    library(coreNLP)
    initCoreNLP()
  },error=function(e){
    if(grepl("downloadCoreNLP()",e,fixed = T)) {
      dest_path <- paste0(.libPaths()[1],'/coreNLP/extdata/')
      file.copy(from='Source/StanfordCoreNLP.properties',to=dest_path,overwrite = TRUE)
      downloadCoreNLP()
      initCoreNLP()
    }
    else{
      if(!(dbWarning=="")){
        if(!("rJava" %in% utils::installed.packages()[,1])){
          #utils::install.packages('rJava');
          if(!('rJava' %in% installationFailedPackages)){
            installationFailedPackages <- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\n\r\ninstall.packages('rJava', repos = 'http://cloud.r-project.org/' )")
            write(installationFailedPackages, paste0("InstallationFailedPackages.txt"), sep="\n")
          }
        }
      }else{
        shiny::showNotification(e)
      }
    }
  })
  ##THIS CODE CHUNK CHECKS FOR FAILED PACKAGES AND PUTS THEM IN FILE
  
  if(!is.null(installationFailedPackages) && length(installationFailedPackages)>0){
    tmp1 <- paste0(installationFailedPackages, collapse= "','")
    if(installationFailedRDRPOSTagger == TRUE && installationFailedOpenNLPModels ==TRUE){
      installationFailedPackages <<- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')\r\n\r\n===============Run following command after running previous command================\r\n\r\ninstall.packages('RDRPOSTagger', repos ='http://www.datatailor.be/rcube', type = 'source',INSTALL_opts = '--no-multiarch')\r\n\r\n===============Run following command after running previous command================\r\n\r\ninstall.packages('openNLPmodels.en', repos = 'http://datacube.wu.ac.at/' , type = 'source')")
    }else if(installationFailedRDRPOSTagger == TRUE){
      installationFailedPackages <<- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')\r\n\r\n Run following command after running previous command \r\n\r\n install.packages('RDRPOSTagger', repos ='http://www.datatailor.be/rcube', type = 'source',INSTALL_opts = '--no-multiarch')")
    }else if(installationFailedOpenNLPModels == TRUE){
      installationFailedPackages <<- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')\r\n\r\n Run following command after running previous command\r\n\r\n
                                           install.packages('openNLPmodels.en', repos = 'http://datacube.wu.ac.at/' , type = 'source')")
    }else{
      installationFailedPackages <<- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\ninstall.packages(c('", tmp1, "'), repos = 'http://cloud.r-project.org/')")
    }
    write(installationFailedPackages, paste0("InstallationFailedPackages.txt"), sep="\n")
  }else{
    if(installationFailedRDRPOSTagger == TRUE && installationFailedOpenNLPModels ==TRUE){
      installationFailedPackages <<- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command  \r\n\r\n install.packages('RDRPOSTagger', repos ='http://www.datatailor.be/rcube', type = 'source',INSTALL_opts = '--no-multiarch')\r\n\r\n===============Run following command after running previous command================\r\n\r\n
                                           install.packages('openNLPmodels.en', repos = 'http://datacube.wu.ac.at/' , type = 'source')")
      write(installationFailedPackages, paste0("InstallationFailedPackages.txt"), sep="\n")    
    }else if(installationFailedRDRPOSTagger == TRUE){
      installationFailedPackages <<- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\n\r\ninstall.packages('RDRPOSTagger', repos ='http://www.datatailor.be/rcube', type = 'source',INSTALL_opts = '--no-multiarch')")
      write(installationFailedPackages, paste0("InstallationFailedPackages.txt"), sep="\n")    
    }else if(installationFailedOpenNLPModels == TRUE){
      installationFailedPackages <<- paste0("TIMESTAMP:", format(Sys.time(),"%d_%m_%y_%H:%M:%S"), "\r\n\r\nPlease get the following packages installed, if you don't have the rights to install R packages (or) run the following command in R Console to install the missing packages:\r\n\r\ninstall.packages('openNLPmodels.en', repos = 'http://datacube.wu.ac.at/' , type = 'source')")
      write(installationFailedPackages, paste0("InstallationFailedPackages.txt"), sep="\n")
    }
    
  }
} 

#################################################################################################################################################################################################################################################

loadMains_package<- function(pkgs_df,pkgDir = NULL,minRVersion="3.4.4",
                     bypassPreviousRun = F,savePkgInstallationTable = T){
  # Initializing return values
  installerStatus <- NA
  pkgInstallationTable <- NULL
  if(is.null(pkgs_df) | nrow(pkgs_df) < 1){
    return(list(installerStatus = installerStatus,pkgInstallationTable = pkgInstallationTable))
  }
  
  # Check if the installer has already been run once on this system for faster reload
  files <- list.files("Source")
  savedFileName <- paste0("lastPkgInstallationTable_",R.Version()$version.string,".rds")
  
  if(savedFileName %in% files & !bypassPreviousRun){
    
    # Reading the save file from Source directory
    pkgInstallationTable <- readRDS(paste0("Source/",savedFileName))
    
    currentStatusFlag <- (pkgInstallationTable$pkgName %in% installed.packages(lib.loc = pkgDir)[,1])
    
    # Check if the package got deleted and update table
    pkgInstallationTable$Status[pkgInstallationTable$StatusFlag == T & !currentStatusFlag] <- "This package was deleted from the package repository"
    pkgInstallationTable$StatusFlag[currentStatusFlag] <- FALSE
    
    # Check if the package got added
    pkgInstallationTable$Status[pkgInstallationTable$StatusFlag == F & currentStatusFlag] <- "Installation successful"
    pkgInstallationTable$StatusFlag[currentStatusFlag] <- TRUE
    
    installerStatus <- "Results loaded from last installer run saved in Downloads folder"
    
    return(list(installerStatus = installerStatus,pkgInstallationTable = pkgInstallationTable))
  }
  
  # Hard check for ggplot version
  if("ggplot2" %in% installed.packages(lib.loc = pkgDir)[,1] && packageVersion("ggplot2")=='2.2.1.9000') {
    
    remove.packages("ggplot2")
  }
  
  # Check for minimum version of R required to run brick
  if(!RVersionCheck(minRVersion)){
    
    installerStatus <- paste0("A minimum of ",minRVersion," R version is required to run. Update R and re-run the brick")
    return(list(installerStatus = installerStatus,pkgInstallationTable = pkgInstallationTable))
  }
  
  # Installing mandatory packages reuqired for running installer
  mandatory_package <- c("pkgbuild","curl","miniCRAN","shinycssloaders","versions")
  uninstalled_mandatory_package <- mandatory_package[which(!mandatory_package %in% installed.packages(lib.loc = pkgDir)[,1])]
  if(length(uninstalled_mandatory_package) != 0){
    # Installing unavailable mandatory packages
    OSType=Sys.info()['sysname']
    pkgType = ifelse(OSType == "Windows","win.binary",ifelse(OSType == "Linux","source","mac.binary.el-capitan"))
    
    for(i in 1:length(uninstalled_mandatory_package)){
      installPkg(uninstalled_mandatory_package[i], pkgType, pkgRepo = getOption("repos")["CRAN"], pkgDir)
    }
    
  }
  
  uninstalled_mandatory_package <- mandatory_package[which(!mandatory_package %in% installed.packages(lib.loc = pkgDir)[,1])]
  if(length(uninstalled_mandatory_package) != 0){
    
    installerStatus <- paste0("Following mandatory packages not available to run package installer: ", paste(uninstalled_mandatory_package,collapse = ","))
    return(list(installerStatus = installerStatus,pkgInstallationTable = pkgInstallationTable))
  }
  
  # Check if the system is connected to internet
  if(!has_internet()){
    
    installerStatus <- "System not connected to internet"
    return(list(installerStatus = installerStatus,pkgInstallationTable = pkgInstallationTable))
  }
  
  # Check for Java setup if the package has java dependency
  minJavaVersion <- 1.8
  javaConfig <- checkJavaComaptibility(minJavaVersion)
  
  if(!all(javaConfig)){
    javaStatus <- ifelse(!javaConfig$javaVersion,paste0("Requires Java version greater than:",minJavaVersion),
                         ifelse(!javaConfig$matchArchitechture,"R and Java have incompatible architecture(32 vs 64 bit)",
                                ifelse(!javaConfig$javaHomeSet,"JAVA HOME is not set","Java in not setup on the system")))
  } else {
    javaStatus <- NA
  }
  
  # Getting avaiable packages on CRAN and extracting R version requirements + Java dependency
  cran_packages <- as.data.frame(miniCRAN::pkgAvail(),row.names = F,stringsAsFactors = F)
  cran_packages$minRVersion <- getMinRVersion(cran_packages$Depends)
  cran_packages$minRVersionMajor <- as.numeric(substr(cran_packages$minRVersion,1,1))
  cran_packages$minRVersionMinor <- as.numeric(substring(cran_packages$minRVersion,3))
  cran_packages$isJavaRequired <- as.vector(mapply(isJavaRequired,cran_packages$Package,cran_packages$Depends))
  
  # Installing all the packages required for the brick
  pkgInstallationTable = pkgs_df
  for (i in 1:nrow(pkgs_df)) {
    pkgInstallationTable[i,"Status"] <- tryPackageInstallation(pkgName = pkgInstallationTable[i,"pkgName"],
                                                               pkgRepo = pkgInstallationTable[i,"pkgRepo"],
                                                               pkgType = pkgInstallationTable[i,"pkgType"],
                                                               pkgLoc = pkgInstallationTable[i,"pkgLoc"],
                                                               pkgDir = pkgDir,
                                                               pkgList = cran_packages)
    pkgInstallationTable[i,"StatusFlag"] <- pkgInstallationTable[i,"pkgName"] %in% installed.packages(lib.loc = pkgDir)[,1]
    pkgInstallationTable[i,"statusCode"] <- substr(pkgInstallationTable[i,"Status"],1,4)
  }
  
  installerStatus <- "Installer ran successfully"
  
  # Saving pkgInstallationTable for faster future reloads
  if(savePkgInstallationTable){
    
    saveRDS(pkgInstallationTable,paste0("Downloads/",savedFileName))
  }
  
  return(list(installerStatus = installerStatus,pkgInstallationTable = pkgInstallationTable))
}

# Package installation from CRAN like repo
tryPackageInstallation <- function(pkgName, pkgRepo=getOption("repos")["CRAN"], pkgType = "source", pkgLoc = "CRAN", pkgDir=NULL, pkgList=NULL, javaStatus = NA){
  
  installStatus <- NA
  
  if(is.na(pkgName) | is.na(pkgType) | is.na(pkgRepo)){
    
    return(installStatus)
  }
  
  print(paste0("Installing ",pkgName," ..."))
  
  # Check if the package is already installed
  if(pkgName %in% installed.packages(lib.loc = pkgDir)[,1]){
    
    installStatus <- "PS01: Package already installed"
    return(installStatus)
  }
  
  # Check if the system is connected to internet
  if(!has_internet()){
    
    installStatus <- "ER07: System not connected to internet"
    return(installStatus)
  }
  
  # Installing coreNLPDependency for coreNLP package
  if(pkgName == "coreNLPDependency"){
    installStatus <- coreNLPDependencyCheck(pkgDir = pkgDir,pkgRepo = pkgRepo, pkgLoc = pkgLoc)
    return(installStatus)
  }
  
  # Check if the system has reuqired tools to build package from source
  if(pkgType == "source" & !pkgbuild::has_build_tools()) {
    
    installStatus <- "ER06: Could not find tools necessary to compile a package from source"
    return(installStatus)
  }
  
  if(pkgLoc == "CRAN"){
    # CRAN package installation steps
    if(is.null(pkgList)){
      # Getting avaiable packages on CRAN and extracting R version requirements + Java dependency
      pkgList <- as.data.frame(miniCRAN::pkgAvail(),row.names = F,stringsAsFactors = F)
      pkgList$minRVersion <- getMinRVersion(pkgList$Depends)
      pkgList$minRVersionMajor <- as.numeric(substr(pkgList$minRVersion,1,1))
      pkgList$minRVersionMinor <- as.numeric(substring(pkgList$minRVersion,3))
      pkgList$isJavaRequired <- as.vector(mapply(isJavaRequired,pkgList$Package,pkgList$Depends))
    }
    
    # Check if package is available on CRAN
    if(!pkgName %in% pkgList[[1]]) {
      
      # Check whether source version of package is available on CRAN if not windows or cran binaries
      if(pkgType != "source"){
        sourcePkgList <- as.data.frame(miniCRAN::pkgAvail(),row.names = F,stringsAsFactors = F)
        if(pkgName %in% sourcePkgList[[1]]){
          installStatus <- paste0("ER08: The ", pkgType, " version is not available on CRAN. However source version of pacakge is avaialable on CRAN")
          return(installStatus)
        }
      }
      
      installStatus <- paste0("ER01: This package is not available on CRAN")
      return(installStatus)
    }
    
    # Check for minimum required R version for the package
    minRVersionStatus <- checkMinRVersion(pkgName,pkgList)
    if(!minRVersionStatus$isSatisfied) {
      installStatus <- paste0("ER02: The latest package version on CRAN requires a minimum R version of ",minRVersionStatus$minVersionReq,". Either update your R version or install an older package version compatible with your current R version.")
      return(installStatus)
    }
    
    # Check if java dependency is required
    if(pkgList[which(pkgList$Package == pkgName),]$isJavaRequired & is.na(javaStatus)){
      return(paste0("ER03: Installation unsuccessful. Please refer to link for further action"))
    }
    
    # Try installating
    OSType = Sys.info()['sysname']
    if(OSType != "Windows" && OSType != "Linux")
    {
      installPkg(pkgName)
    }else{
      installPkg(pkgName,pkgType = pkgType,pkgRepo = pkgRepo, pkgDir=pkgDir)
    }
    
    if(pkgName %in% installed.packages(lib.loc = pkgDir)[,1]){
      
      installStatus <- "PS02: Installation successful"
      return(installStatus)
    }
    
    # Check which dependencies if any did not get installed
    dependencies <- miniCRAN::pkgDep(pkgName,suggests = FALSE,enhances = FALSE)
    dependencies <- dependencies[which(!dependencies %in% pkgName)]
    uninstalled_dependencies <- dependencies[which(!dependencies %in% installed.packages(lib.loc = pkgDir)[,1])]
    if(length(uninstalled_dependencies)>0){
      installStatus <- paste0("ER04: Following dependent pacakges not installed: ", paste(uninstalled_dependencies,collapse = ", "))
    } else if(length(uninstalled_dependencies) == 0 &&  pkgType!= "mac.binary.el-capitan" ){
      installOldPkg(pkgName, pkgDir)
      if(pkgName %in% installed.packages(lib.loc = pkgDir)[,1]){
        
        installStatus <- "PS02: Installation successful"
      }else{
        installStatus <- "ER05: Installation unsuccessful. All System requirements for the package are not met"
      }
    }
    else {
      installStatus <- "ER05: Installation unsuccessful. All System requirements for the package are not met"
    }
    return(installStatus)
    
  } else {
    
    # nonCRAN package installation steps
    if(pkgLoc == "nonCRAN"){
      
      installPkg(pkgName,pkgType = pkgType,pkgRepo = pkgRepo, pkgDir=pkgDir)
      
      if(pkgName %in% installed.packages(lib.loc = pkgDir)[,1]){
        installStatus <- "PS02: Installation successful"
      } else {
        installStatus <- "ER05: Installation unsuccessful. All System requirements for the package are not met"
      }
      return(installStatus)
    } else if (pkgLoc == "github"){
      
      # Check if devtools is installed else install
      if(!"devtools" %in% installed.packages(lib.loc = pkgDir)[,1]){
        if(!(TRUE %in% installPkg("devtools"))){
          reutrn("ER06: Devtools package is required to install package from source")
        }
      }
      try(devtools::install_github(pkgRepo, lib = pkgDir))
      
      if(pkgName %in% installed.packages(lib.loc = pkgDir)[,1]){
        installStatus <- "PS02: Installation successful"
      } else {
        installStatus <- "ER05: Installation unsuccessful. All System requirements for the package are not met"
      }
    } else {
      reutrn("ER00: Incorrect arguments passed for package installation")
    }
  }
}

# Wrapper for install.packages
installPkg <- function(pkgName,pkgType = "source",pkgRepo = getOption("repos")["CRAN"],pkgDir=NULL){
  # Status <-
  tryCatch({
    utils::install.packages(pkgName,lib = pkgDir, dependencies = c("Depends","Imports","LinkingTo"), repos = pkgRepo, type = as.character(unique(pkgType)) ,quiet = T)
    return(TRUE)
  }, 
  error = function(e){
    warning(e)
    return(FALSE)
  }, warning = function(e){
    warning(e)
    return(FALSE)
  }
  )
  return(NULL)
}

# Get version of R from Depends string
getMinRVersion <- function(string) {
  # test case
  # string <- c("R (>= 3.2.0), xts(>= 0.9-0), zoo, TTR(>= 0.2), methods","TTR(>= 0.2), methods,R (>= 3.2.0)","TTR(>= 0.2), methods, R (>= 3.2.0)")
  
  R_version <- regmatches(string, gregexpr("[^A-Za-z]R\\s*\\(\\s*>=.*?\\)|^R\\s*\\(\\s*>=.*?\\)", string))
  R_version <- lapply(R_version, function(x) if(identical(x, character(0))) NA_character_ else x)
  gsub(")","",gsub(".*R\\s*\\(\\s*>=\\s*" ,"",R_version))
}

# Check minimum required r version
checkMinRVersion <- function(pkgName,packageList){
  major <- as.numeric(R.version$major)
  minor <- as.numeric(R.version$minor)
  # pkgName <- "adapr"
  pkg_row <- packageList[which(packageList$Package == pkgName),]
  
  if(!all(is.na(pkg_row$minRVersion))){
    pkg_row <- pkg_row[which(pkg_row$minRVersionMajor == min(pkg_row$minRVersionMajor)),]
    pkg_row <- pkg_row[which(pkg_row$minRVersionMinor == min(pkg_row$minRVersionMinor)),]
  }
  
  min_version_req <- pkg_row$minRVersion
  min_major_version_req <- pkg_row$minRVersionMajor
  min_minor_version_req <- pkg_row$minRVersionMinor
  
  if(is.na(min_version_req)){
    return(list(isSatisfied = TRUE,minVersionReq = ""))
  }
  
  if(major>min_major_version_req | (major == min_major_version_req & minor>=min_minor_version_req)){
    return(list(isSatisfied = TRUE,minVersionReq = ""))
  } else {
    return(list(isSatisfied = FALSE,minVersionReq = as.character(min_version_req)))
  }
}

# Check if Java needs to be configured for the system
isJavaRequired <- function(pkgName,string){
  if(is.na(string)){
    return(FALSE)
  }
  # Add Packages that directly depends on Java here
  javaDependentPackages <- c("rJava")
  if(pkgName %in% javaDependentPackages){
    return(TRUE)
  }
  
  return(FALSE)
  
  # pkgDependencies <- trimws(gsub("\\s*\\([^\\)]+\\)","",strsplit(string,",")[[1]]))
  # return(any(javaDependentPackages %in% pkgDependencies))
}

# Function to check if the installed version of R is 3.4.3 to match requirements for Foundation Bricks
# Inputs : 
#     minVersion: Minimum R's version  
# 
# Output : 
#     returns R version if it's 3.4.3
RVersionCheck <- function(minVersion) {
  result <- strsplit(R.Version()$version.string, " ")[[1]][3]
  
  if(result < minVersion){
    warning("minimum version requirement of r not met")
    return(FALSE)
  }else{
    return(TRUE)
  }
}

# Function to check if the installed version of Java is 1.8 to match system requirements of 'rJava' Package
# Inputs :
#     verbose: Set to FALSE by default. Else, if set as TRUE, returns additional details about 
#              version of Java and R which has been called inside the function
#     minJavaVersion: minimum Java version required
# 
# Output : Logical TRUE/FALSE output
#     TRUE: If the installed version of Java is 1.8
#     FALSE: If the installed version of Java is not 1.8     
CheckJavaVersion <- function(minJavaVersion=1.8, verbose = F){
  tryCatch({
    OSType <- Sys.info()['sysname']
    systemInfo <- system("java -version")
    if(systemInfo == 127 | systemInfo == 1){
      return(FALSE)
    }else if(systemInfo == 0){
      sysinfo <- system2("java", "-version", stdout = 'stdout.txt', stderr = 'stderr.txt')
      sysinfo <- readLines('stderr.txt')
      sysinfo <- paste(sysinfo,collapse = " ")
      sysinfo <- substr(sysinfo,stringr::str_locate(sysinfo,'version')[2]+3,stringr::str_locate(sysinfo,'version')[2]+5)
    }
    if(verbose == T){
      base::system("java -version")
    }
    if(file.exists('stderr.txt')){
      file.remove("stderr.txt")
    }
    if(file.exists('stdout.txt')){
      file.remove("stdout.txt")
    }
    # Check if the version of Java is 1.8
    if(sysinfo >= minJavaVersion){
      return(TRUE)
    }else{
      warning('minimum version requirements for Java not met')
      return(FALSE)
    }
  }, error = function(e){
    warning(e)
    return(FALSE)
  }, warning = function(e){
    warning(e)
    return(FALSE)
  })
}

# Function to match architecture build of R and java installled on a system(32/64-bit) 
# Inputs: 
#     verbose: Set to FALSE by default. Else, if set as TRUE, returns additional details about 
#              version of Java and R which has been called inside the function
# 
# Output: Logical TRUE/FALSE output
#     TRUE: If the architecture of both R and Java matches(32/64-bit)
#     FALSE: If the architecture of both R and Java doesn't match(32/64-bit)     
isJavaRMatch <- function(){
  OSType <- Sys.info()['sysname']
  rArch <- R.Version()
  rArch <- substr(rArch$arch, nchar(rArch$arch)-1, nchar(rArch$arch))
  if(rArch == "86"){
    rArch<-"32"
  }
  tryCatch({
    javaArch <- system(paste0('java -d', rArch, ' -version'))
    javaArchD <- system(paste0('java -D', rArch, ' -version'))
    if(javaArch == 0 | javaArchD == 0){
      return(TRUE)
    }else{
      return(FALSE)
    }
  }, error = function(e){
    warning("Architecture for the installed Versions of R and java don't match")
    return(FALSE)
  }, warning= function(e){
    warning("Architecture for the installed Versions of R and java don't match")
    return(FALSE)
  })
}

# Check if all Java requirements are met
checkJavaComaptibility <- function(minJavaVersion) {
  
  # Check JAVA version
  javaVersion <- CheckJavaVersion(minJavaVersion)
  # Check JAVA architecture
  matchArchitechture <- isJavaRMatch()
  # Check JAVA HOME
  javaHomeSet <- base::Sys.getenv("JAVA_HOME") == ""
  
  return(list(javaVersion = javaVersion,matchArchitechture = matchArchitechture, javaHomeSet = javaHomeSet))
}

# Check if the system is connected to internet
# https://stackoverflow.com/questions/5076593/how-to-determine-if-you-have-an-internet-connection-in-r
has_internet <- function(){
  !is.null(curl::nslookup("r-project.org", error = FALSE))
}

# Installing Older version of package from MRAN repo
installOldPkg <- function(pkgName,pkgDir = NULL){
  #check R version of user
  version_year <- R.version$year
  version_month <- R.version$month
  version_day <- R.version$day
  user_R_Version_date <- paste0(version_year, sep = "-", version_month, sep = "-", version_day)
  
  versionHistory <- versions::available.versions(pkgName)
  pkg_version <- versionHistory[[1]]$version[which(user_R_Version_date > versionHistory[[1]]$date)[1]]
  try(
    if(!(is.na(pkg_version))){
      versions::install.versions(pkgName, pkg_version)
    }
  )
  if(pkgName %in% installed.packages(lib.loc = pkgDir)[,1]){
    return(paste0("Successfully installed version ",versions::installed.versions(pkgName)," of package ",pkgName))
  } else {
    return("Installation unsuccessful upgrade your R version")
  }
}

# DownloadCoreNLP
coreNLPDependencyCheck <- function(pkgDir = NULL,pkgRepo,pkgLoc = ""){
  tryCatch({
    # Check if depencency for coreNLP is already installed
    library(coreNLP)
    initCoreNLP()
    installStatus <- "PS01: Dependency package already installed"
  },error=function(e){
    
    # To Install JAR if not already installed pass pkgLoc argument as "stanford", else it will not try installing
    if(pkgLoc != "stanford"){
      
      installStatus <- "ER09: CoreNLP dependency will not install by default. We recommend to connect to LAN/ faster internet as the installation requires download of ~400 MB file and then press Retry Installation"
    } else if(!("rJava" %in% utils::installed.packages()[,1])){
      
      installStatus <- "ER09: Following dependent package not installed: rJava"
    } else if(grepl("downloadCoreNLP()",e,fixed = T)) {
      
      dest_path <- paste0(ifelse(is.null(pkgDir),.libPaths()[1],pkgDir),'/coreNLP/extdata/')
      file.copy(from=pkgRepo,to=dest_path[1],overwrite = TRUE)
      downloadCoreNLP()
      initCoreNLP()
      installStatus <- "PS02: Dependency package successfully installed"
    } else {
      
      installStatus <- paste0("ER09: ", e)
    }
  })
}


