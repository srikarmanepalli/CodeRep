library(testthat)

library(futile.logger)
set.seed(7)

# setwd('/home/ashwin/Documents/Bricks/mugitlab/08_FoundationBrick_PanelData/Source/')

flog.threshold(INFO)
# flog.appender(appender.file("./testCaseSummary.log"))
flog.appender(appender.file("./testCases.log"))
testResults <- as.data.frame(test_file("testCases.R"))

summary <- list()
summary[['Number of tests run']] <- nrow(testResults)
summary[['Numeber of tests failed']] <- sum(testResults$failed)

flog.info( knitr::kable(testResults))
flog.info("*************************************************************************************************************")
flog.info("Summary of test cases for this build")
flog.info(knitr::kable(as.data.frame(summary)))


if(sum(testResults$failed) > 0){
  stop()
}else{
  print("All tests passed. Pushing build...")
}


#### Coverage & Metrics ####

library(devtools)
library(covr)
library(lintr)

testPackageName<-"testcovr"
brickName<-"Panel Regression"

sourceFileLocation<-"panelRegressionUtils.R"
testFIleLocation<-"testCases.R"

total_coverage<-covr::file_coverage(source_files = sourceFileLocation,test_files = testFIleLocation)

total_coverage_data<-as.data.frame(total_coverage)
total_coverage_string<-capture.output(total_coverage,file = NULL,type = "message")
unit_test_coverage_percentage<-"0%"
unit_test_coverage_percentage<-strsplit(total_coverage_string[1],split = ": ")[[1]][2]
unit_test_coverage<-strsplit(unit_test_coverage_percentage,split = "%")[[1]][1]

unlink(testPackageName,recursive = T)

number_of_unit_test <- nrow(testResults)

# Running lintr
lintResult <- as.data.frame(lint('panelRegressionUtils.R'))

# Final variables
lines_of_code <- length(readLines(file('panelRegressionUtils.R')))
code_coverage <- unit_test_coverage_percentage
code_coverage <- regmatches(code_coverage, gregexpr(pattern = "(\\d{2,3}.\\d{2}%)", code_coverage))[[1]]
no_unit_tests <- nrow(testResults)
int_coverage <- "0"
issues <- nrow(lintResult[which(lintResult$type %in% c('error', 'warning')), ])

## Use RPostgreSQL package to connect into database directly and import tables into dataframes.
# library("RPostgreSQL")
# ## loads the PostgreSQL driver
# drv <- dbDriver("PostgreSQL")
# ## Open a connection
# con <- dbConnect(drv, host='172.25.1.30', port='5432', dbname="metric", user='postgres', password='postgres')
# 
# ## Submits a statement
# dbSendQuery(con, paste0("INSERT INTO eoc_brick_metrics VALUES (\'",brickName,"\',\'",lines_of_code,"\',\'",no_unit_tests,"\',\'",issues,"\',\'",int_coverage,"\',\'" ,code_coverage,"\');"))
# 
# ## Closes the connection
# dbDisconnect(con)
# ## Frees all resources in the driver
# dbUnloadDriver(drv)